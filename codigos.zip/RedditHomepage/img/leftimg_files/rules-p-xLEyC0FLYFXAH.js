/*
 Quantcast measurement tag
 Copyright (c) 2008-2018, Quantcast Corp.
*/
(function(a,b,c){__qc("rules",[a])})("p-xLEyC0FLYFXAH",window,document);